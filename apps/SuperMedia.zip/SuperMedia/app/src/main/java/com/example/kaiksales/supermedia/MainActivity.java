package com.example.kaiksales.supermedia;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Scanner;


public class MainActivity extends AppCompatActivity {
    private EditText n1;
    private EditText n2;
    private Button calcular;
    private TextView resu;
    private double uni1;
    private double uni2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        n1 = (EditText) findViewById(R.id.n1);
        n2 = (EditText) findViewById(R.id.n2);
        calcular = (Button) findViewById(R.id.calcular);
        resu = (TextView) findViewById(R.id.resu);
        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uni1 = Double.parseDouble(n1.getText().toString());
                uni2 = Double.parseDouble(n2.getText().toString());
                Double media = calcularMedia(uni1, uni2);
                resu.setText(media.toString());
            }
        });


    }

    private double calcularMedia(double uni1, double uni2) {
        double mediafim = ((uni1 * 4) + (uni2 * 6) / 10);
        return mediafim;
    }
}
