package com.example.kaiksales.kedzs;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela_Inicial_3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela__inicial_3);

        Button Perfil = (Button) findViewById(R.id.perfil);

        Perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //setContentView(R.layout.activity_tela2);
                Intent intent = new Intent(Tela_Inicial_3.this, Tela_perfil.class);
                startActivity(intent);

            }
        });
        Button Favoritos = (Button) findViewById(R.id.favorit);

        Favoritos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //setContentView(R.layout.activity_tela2);
                Intent intent = new Intent(Tela_Inicial_3.this, Tela_Favoritos.class);
                startActivity(intent);

            }
        });
    }
    }


