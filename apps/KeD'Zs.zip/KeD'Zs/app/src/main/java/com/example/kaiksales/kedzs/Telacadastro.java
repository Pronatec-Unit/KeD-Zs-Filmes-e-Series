package com.example.kaiksales.kedzs;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Telacadastro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telacadastro);

        Button TelaInicial = (Button) findViewById(R.id.cadastrar);

        TelaInicial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //setContentView(R.layout.activity_tela2);
                Intent intent = new Intent(Telacadastro.this, Tela_Inicial_3.class);
                startActivity(intent);
                Telacadastro.this.finish();
            }
        });
        Button voltar = (Button) findViewById(R.id.voltei);

        TelaInicial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //setContentView(R.layout.activity_tela2);
                Telacadastro.this.finish();
            }
        });
    }
}
