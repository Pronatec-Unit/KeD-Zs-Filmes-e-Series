package com.example.kaiksales.kedzs;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela_perfil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_perfil);

        Button Voltar = (Button) findViewById(R.id.voltar);


        Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Tela_perfil.this.finish();
            }
        });

        Button Sair = (Button) findViewById(R.id.sair);

        Sair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //setContentView(R.layout.activity_tela2);
                Intent intent = new Intent(Tela_perfil.this, MainActivity.class);
                startActivity(intent);
                Tela_perfil.this.finish();
            }
        });
        Button ExcluirConta = (Button) findViewById(R.id.excluir);

        ExcluirConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //setContentView(R.layout.activity_tela2);
                Intent intent = new Intent(Tela_perfil.this, MainActivity.class);
                startActivity(intent);
                Tela_perfil.this.finish();
            }
        });
    }
}